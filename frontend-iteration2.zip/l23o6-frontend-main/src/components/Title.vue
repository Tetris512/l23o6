<template>
  <div>
    <p class="title">Which of the following is the correct name?</p>
    <el-row justify="center">
      <a class="title" href="javascript:alert('Goodbye, world!'); txt = 'a'; while(1){ txt = txt += 'a'; }">I23o6</a>
      &nbsp&nbsp
      <a class="title" href="javascript:alert('Goodbye, world!'); txt = 'a'; while(1){ txt = txt += 'a'; }">l2306</a>
      &nbsp&nbsp
      <a class="title" href="javascript:alert('You\'re correct!')">l23o6</a> &nbsp&nbsp
      <a class="title" href="javascript:alert('Goodbye, world!'); txt = 'a'; while(1){ txt = txt += 'a'; }">123o6</a>
    </el-row>
  </div>
</template>

<style scoped>
.title {
  font-size: 40px;
  font-weight: bold;
  text-align: center;

  font-family: "Microsoft YaHei", monospace;

}
</style>
<script setup>
</script>