// const SERVER_ADDR = "https://mock.apifox.cn/m1/2555088-0-default"
const SERVER_ADDR = "http://localhost:8080"
export { SERVER_ADDR }