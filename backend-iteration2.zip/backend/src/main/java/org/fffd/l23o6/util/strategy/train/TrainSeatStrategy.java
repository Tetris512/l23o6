package org.fffd.l23o6.util.strategy.train;

public abstract class TrainSeatStrategy {

    public interface SeatType {
        public String getText();
    }
    
}
