package org.fffd.l23o6.pojo.vo.order;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OrderIdVO {
    private Long id;
}
