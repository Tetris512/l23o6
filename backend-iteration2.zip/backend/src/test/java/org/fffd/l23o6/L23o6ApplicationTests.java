package org.fffd.l23o6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L23o6ApplicationTests {

    @Test
    void contextLoads() {
    }

}
